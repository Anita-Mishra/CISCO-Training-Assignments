package com;

import java.util.Scanner;

//Program to calculate sum of the digits.

public class Program4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//Taking input from user
		
		System.out.println("Enter Number");
		int number=sc.nextInt();
		
		
		int i=0,sum=0,remainder=0;
		while(number!=0)
		{
			remainder=number%10;
			number=number/10;
			sum=sum+remainder;
			i++;
		}
		System.out.println("Digits sum is "+sum);

	}

}
