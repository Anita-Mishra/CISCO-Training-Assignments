package com;
import java.util.Scanner;
//Reverse Program
public class Problem2 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		//Taking input from user
		
		System.out.println("Enter Number to be reversed");
		int number=sc.nextInt();
		
		
		int reverse=0,remainder=0,i=0;
		
		//reverse logic
		while(number!=0){
			remainder=number%10;
			number=number/10;
			reverse=reverse*10+remainder;
			i++;
		}
		System.out.println(reverse);

	}

}
