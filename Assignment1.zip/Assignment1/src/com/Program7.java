package com;

//Program which shows overriding and overloading using the concept of polymorphism and inheritance.

class Area{
	
	public double calculateArea(int radius){
		double area=3.14*radius*radius;
		return area;
	}
	//overloading example
	public double calculateArea(int length,int width){
		double area=length*width;
		return area;
	}
	
}
public class Program7 extends Area{
	//overriding
	public double calculateArea(int length)
	{
		double area= length*length;
		return area;
	}
	public static void main(String[] args) {
		Program7 p1=new Program7();
		System.out.println("Area of square: "+p1.calculateArea(4));
		
		Area a1=new Area();
		System.out.println("Area of circle: "+a1.calculateArea(3));
		System.out.println("Area of Rectangle: "+a1.calculateArea(5, 3));

	}

}
