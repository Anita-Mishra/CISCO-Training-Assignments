package com;

//program to use encapsulation & inheritance together.

class Vehicle{				//parent class
	int speed;

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	public void display(){
		System.out.println("I am Vehicle");
	}
	
}
public class Program10 extends Vehicle {		//child class

	public void display()
	{
		System.out.println("I am Vehicle child");
	}
	public static void main(String[] args) {
		Vehicle v1=new Vehicle();
		Vehicle p=new Program10();
		p.setSpeed(6);		//encapsulation
		System.out.println(p.getSpeed());	//encapsulation
		p.display();	//inheritance
		v1.display();	//inheritance
	}

}
