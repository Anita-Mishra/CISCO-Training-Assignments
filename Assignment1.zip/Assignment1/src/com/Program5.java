package com;

import java.util.Scanner;

//Program to print fibonacci series

public class Program5 {

	public static void main(String[] args) {
		int firstno=1,secondno=1,range=0,thirdno=0,i=0;
		System.out.println("Enter fibonacci range");
		
		Scanner sc=new Scanner(System.in);
		range=sc.nextInt();
		System.out.print(firstno+" "+secondno);
		while(i<=range)
		{
			thirdno=firstno+secondno;
			System.out.print(" "+thirdno);
			firstno=secondno;
			secondno=thirdno;
			i++;
		}

	}

}
