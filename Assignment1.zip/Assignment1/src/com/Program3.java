package com;

//multiple inheritance problem

interface Figure{
	public void display();
}

interface Area1{
	public int findArea(int length,int width);
}
public class Program3 implements Figure, Area1 {

	public static void main(String[] args) {
		Program3 p=new Program3();
		System.out.print("My Area is: ");
		System.out.print(p.findArea(4, 3));
		p.display();

	}

	@Override
	public int findArea(int length,int width) {
		// TODO Auto-generated method stub
		return length*width;
	}

	@Override
	public void display() {
		System.out.print(" and I am Square");
		
	}

}
