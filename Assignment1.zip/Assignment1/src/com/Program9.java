package com;

import java.util.Scanner;

//Program to print day of week name using switch case.

public class Program9 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("......Menu.......");
		System.out.println("Press 1 to print Monday");
		System.out.println("Press 2 to print Tuesday");
		System.out.println("Press 3 to print Wednesday");
		System.out.println("Print 4 to print Thursday");
		System.out.println("Print 5 to print Friday");
		System.out.println("Print 6 to print Saturday");
		System.out.println("Print 7 to print Sunday");
		
		System.out.println("Enter your day number:");
		int daynumber=s.nextInt(); 
		
		switch(daynumber)
		        {
		            case 1:
		                System.out.println("Monday");
		                break;
		            case 2:
		                System.out.println("Tuesday");
		                break;
		            case 3:
		                System.out.println("Wednesday");
		                break;
		            case 4:
		                System.out.println("Thursday");
		                break;
		            case 5:
		                System.out.println("Friday");
		                break;
		            case 6:
		                System.out.println("Saturday");
		                break;
		            case 7:
		                System.out.println("Sunday");
		                break;
		            default:
		                System.out.println("Invalid day number");
		                break;
		        }

	}

}
