package com;

import java.util.Scanner;

//Program to check prime number.

public class Program6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number");
		int number=sc.nextInt();
		int i=2,flag=0;;
		while(i<=number/2)
		{
			if(number%i==0)
			{
				flag=1;
				break;
			}
			i++;
		}
		if(flag==0)
			System.out.println("Number is prime");
		else
			System.out.println("Number is not prime");
	}

}
