package com;

//Program to swap two numbers without using third variable.

public class Program8 {

	public static void main(String[] args) {
		int number1=2,number2=5;
		
		System.out.println("Number Before Swap");
		System.out.println(number1+" "+number2);
		
		//swap logic
		number2=number2-number1;
		number1=number2+number1;
		number2=number1-number2;
		
		System.out.println("Number after swap");
		System.out.println(number1+" "+number2);
	}

}
